<?if(!isset($_SESSION['aid']))
	require "inc/config.php";
	?>

						 <div  >  <span class="pull-right" style="margin-top:-95px;font-size:18px;">  </span></div>
						 
						 
								
     <?    $paymentssql="select * from payments";
	  $stmt=$conn->prepare($paymentssql);
    
   $stmt->execute();
?>		
				
		<div class="block">
		   <div class="block-header">
           
        </div>
	<div class="block-content">
	 
		<table class="table table-bordered table-striped">
			<thead>
			 
				<tr>
				<th class="text-center">S No</th>
				  
					<th class="text-center">Payment Ledger Name</th>
					<th class="text-center">Date</th>
					<th class="text-center">Amount</th>
					
					
					
					
					
				</tr>
			</thead>
			<tbody>
			
			
					<?while($row=$stmt->fetch()){?>
				<tr>
					<td><? echo ++$counter; ?></td>
					
					<td class="text-left"><?   $pled_id=$row['pled_id'];
											    if ($row['pled_id']==0)
													echo"-";
												 else {
												 $sql="select pledname from paymentledger where pled_id=:pled_id";
												$stm=$conn->prepare($sql);
												$stm->bindParam(':pled_id',$pled_id);
													 
													 $stm->execute();
													  $result=$stm->fetch();
													 echo $result['pledname'];} 													 
												 ?></td>

<td class="text-left"><? echo $row['dt']; ?></td>					 
<td class="text-right" style="padding-right:50px;"><? echo $row['amt']; ?></td>					 
				
				<?php
                        $sum += $row['amt'];
                           ?></tr>
				<?}?>
			</tbody>
			
			                          <tfoot>
			                           <tr>
										<td colspan="3" style="text-align:center;"><B>Total</B></td>
										<td class="text-right" style="padding-right:50px;"><B><? echo  $sum; ?></b></td>
										</tr>
										</tfoot>
		</table>
	</div>
</div>		
				
				