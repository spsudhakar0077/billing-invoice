<?php
//including the database connection file
include_once("config.php");

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC"); // using mysqli_query instead



?>

<html>
<head>	
	<title>Homepage</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
   <div class="viewbut">
                       <a href="add.html"><button class="button button1"> ADD PERSON</button></a>
                               <button class="button button2" onclick="myFunction()">PRINT </button>
                               <button class="button button3">Red</button>
                                 
                                   <button class="button button5">Black</button>
                    </div><br/><br/>

	<table  id="customers" >

	<tr bgcolor='#CCCCCC'>
		<td>Name</td>
		<td>DATE</td>
		<td>AMOUNT</td>
		<td>      </td>
		<td >INTEREST</td>
			</tr>
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	$sum=0;
	$sum1=0;
while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['name']."</td>";
		echo "<td>".$res['age']."</td>";
		echo "<td>".$res['email']."</td>";	
		echo "<td></td>";
		echo "<td>".$res['interst']."</td>";
		echo "</tr>";
             $sum += $res['email'];
	          $sum1 += $res['interst'];
	
	
	}
	
      echo "<td></td>"; echo "<td>TOTAL AMOUNT</td>"; echo "<td>". $sum."</td>";
      echo "<td>TOTAL INTEREST</td>"; echo "<td>". $sum1."</td>";
	?>
	
	
	</table>
	
</body>
<script>
function myFunction() {
  window.print();
}
</script>

</html>
